let cardBody = document.querySelector('#cardBody');
let btnAltreInfo = document.querySelector('#btnAltreInfo');

let prodottiInformatica = [];


function scegliProdottoInformatica(){

    let prodottiScelti = 'https://dummyjson.com/products/category/laptops'; 

        fetch(prodottiScelti)
            .then(response => {
                return response.json();
            })
            .then(prodotto =>{
               prodottiInformatica.push(prodotto.products);
               stampaProdottiInformatica(prodotto.products);
               console.log(prodotto);
            })
            
}
scegliProdottoInformatica(); 
// console.log(prodottiSkincare);

function stampaProdottiInformatica(prodottiInformatica){
    prodottiInformatica.forEach(prodottoInformatica => {
        let card= `<div class="swiper-slide">
                                <div class="card">
                                    <div class="imgProdotto" style="background-image: url(${prodottoInformatica.thumbnail})"></div>
                                    <div class="card-body d-flex flex-column">
                                    <h5 id="nomeSkincare" class="card-title">${prodottoInformatica.title}</h5>
                                    <p id="brandSkincare" class="card-text">${prodottoInformatica.brand}</p>
                                    <p id="descrizioneSkincare" class="card-text">${prodottoInformatica.description}</p>
                                    <p id="prezzoSkincare" class="card-text">${prodottoInformatica.price}€</p>
                                    <button id="btnAltreInfo" type="button" class="btn btn-primary mt-auto" data-bs-toggle="modal" data-bs-target="#prodotto1Modal"> Altre info </button>
                                    </div>
                                </div>
    </div>`;
        cardBody.innerHTML += card;
    }); 
} 

let btnCheckout = document.querySelector('#btnCheckout');
let listaProdotti = document.querySelector('#listaProdotti');
let checkboxDelete = document.querySelector('#checkboxDelete');
let calcoloTotale = document.querySelector('#calcoloTotale');


function povero(){
    alert("Non puoi acquistare, ti sei dimenticato di essere povero!");
}

btnCheckout.addEventListener('click', povero)

// let carrello = localStorage.getItem('arrayCarrello');
// let carrelloParse = JSON.parse(carrello); //arrayProdotti
let carrello = JSON.parse(localStorage.getItem('arrayCarrello'));


popolaCarrello();

function popolaCarrello(){
    carrello.forEach(elemento => {
        listaProdotti.innerHTML += `<li class="d-flex justify-content-between align-items-center mb-3 fw-bold fs-4" carrello_id="${elemento.carrello_id}"> <img src="${elemento.prodotto.thumbnail}" class="img-fluid" pe-0" style="width: 25%" id="imgCart"> ${elemento.prodotto.title} - ${elemento.prodotto.price}€ <button class="btn btnElimina"> </button></li>
        `; //prezzo di listino varia a seconda di vari fattori e con periodo di validità
        //elemento.carrello_id numero di riga db (pk autoincrementante)
    });
    
    let btnElimina = document.querySelectorAll('.btnElimina');
    
    [...btnElimina].forEach(btnElimina => {
        btnElimina.addEventListener('click', eliminaProdotto);
    })
    
    calcolaTotale();
}

function calcolaTotale(totale = 0){
    
    carrello.forEach(elemento =>{
        totale += elemento.prodotto.price;
        calcoloTotale.innerHTML = totale;
    })
}


function eliminaProdotto(event){
    console.log(event.target); //o metto event come argomento o uso this
    
    let parent = this.parentNode;
    let idRiga = parent.getAttribute("carrello_id");
    console.log(idRiga);
    
    console.log(this);
    
    this.parentNode.remove();
    
    cercaProdottoLocalStorage(idRiga);

    calcolaTotale();

    calcoloTotale.innerHTML ='';
}


function cercaProdottoLocalStorage(idRiga){

    let elFiltrati = carrello.filter((el) => idRiga != el.carrello_id);

    console.log(elFiltrati);

    localStorage.setItem('arrayCarrello', JSON.stringify(elFiltrati)); //salvare in localStorage gli elementi filtrati

    carrello = elFiltrati; //ricarico elementi nel localStorage perchè lo fa solo al caricamento della pagina una volta a riga 14!
}

//contare gli elementi nel carrello 

let btnCheckout = document.getElementById('#btnCheckout');


function povero(){
    alert("Non puoi acquistare, ti sei dimenticato di essere povero!");
}

btnCheckout.addEventListener('click', povero)



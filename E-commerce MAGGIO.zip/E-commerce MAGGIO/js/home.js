let inputRicerca = document.querySelector('#inputRicerca');
let outputRicerca = document.querySelector('#outputRicerca'); 

let btnRicerca = document.querySelector('#btnRicerca');




class Prodotto{
    constructor(img, nome, descrizione, brand, prezzo){
        this.img = img; 
        this.nome = nome;
        this.descrizione = descrizione;
        this.brand = brand;
        this.prezzo = prezzo;
    }
}

let prodotti = []; 

// funzione per visualizzazione prodotti carosello generico
function scegliProdotto(){

    let prodottiScelti = ['https://dummyjson.com/products/category/skincare', 'https://dummyjson.com/products/category/shoes', 'https://dummyjson.com/products/category/motorcycle', 'https://dummyjson.com/products/category/laptops']; 

    prodottiScelti.forEach(prodottoScelto => {
        fetch(prodottoScelto)
            .then(response => {
                return response.json();
            })
            .then(prodotto =>{
                let prodottoScelto = new Prodotto(prodotto.images, prodotto.title, prodotto.description, prodotto.brand, prodotto.price);
                prodotti.push(prodottoScelto); 
            })
    })
}
scegliProdotto(); 



/* ---------------------------- RICERCA PRODOTTO ---------------------------- */
function cercaProdotto() {
    let nomeProdotto = inputRicerca.value; //salvo in una variabile la ricerca
    nomeProdotto.replace(' ', '+'); //sostituisco spazi con + per permettere la ricerca

    const URLRICERCA = `https://dummyjson.com/products/search?q=${nomeProdotto}`;

    fetch(URLRICERCA)
        .then(response => {
            return response.json()
        })
        .then(mioProdotto => {
            if(mioProdotto.title == undefined){
                outputRicerca.innerHTML = 'Prodotto non trovato';
                inputRicerca.innerHTML = '';
            }else{
                stampaProdotto(mioProdotto.title, mioProdotto.description, mioProdotto.brand, mioProdotto.price);
            }
        })

    function stampaProdotto(nome, descrizione, brand, prezzo){
        outputRicerca.innerHTML = ` <h1>${nome}</h1>
                                    <ul>
                                        <li>${brand}</li>
                                        <li>${descrizione}</li>
                                        <li>${prezzo}</li>
                                    </ul>`;
    }
    
}

btnRicerca.addEventListener('click', cercaProdotto);
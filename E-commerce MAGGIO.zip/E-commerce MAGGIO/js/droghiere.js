let cardBody = document.querySelector('#cardBody');
let btnAltreInfo = document.querySelector('#btnAltreInfo');

let prodottiDrogheria = [];


function scegliProdottoDrogheria(){

    let prodottiScelti = 'https://dummyjson.com/products/category/groceries'; 

        fetch(prodottiScelti)
            .then(response => {
                return response.json();
            })
            .then(prodotto =>{
               prodottiDrogheria.push(prodotto.products);
               stampaProdottiDrogheria(prodotto.products); 
               console.log(prodotto);
            })
            
}
scegliProdottoDrogheria(); 
// console.log(prodottiSkincare);

function stampaProdottiDrogheria(prodottiDrogheria){
    prodottiDrogheria.forEach(prodottoDrogheria => {
        let card= `<div class="swiper-slide">
                                <div class="card">
                                    <div class="imgProdotto" style="background-image: url(${prodottoDrogheria.thumbnail})"></div>
                                    <div class="card-body d-flex flex-column">
                                    <h5 id="nomeSkincare" class="card-title">${prodottoDrogheria.title}</h5>
                                    <p id="brandSkincare" class="card-text">${prodottoDrogheria.brand}</p>
                                    <p id="descrizioneSkincare" class="card-text">${prodottoDrogheria.description}</p>
                                    <p id="prezzoSkincare" class="card-text">${prodottoDrogheria.price}€</p>
                                    <button id="btnAltreInfo" type="button" class="btn btn-primary mt-auto" data-bs-toggle="modal" data-bs-target="#prodotto1Modal"> Altre info </button>
                                    </div>
                                </div>
    </div>`;
        cardBody.innerHTML += card;
    }); 
} 

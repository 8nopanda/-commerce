// function apriPaginaInformazioni(productId) {
    // Reindirizza l'utente alla pagina "Informazioni" con l'ID del prodotto come parametro nella query string
//     window.location.href = informazioni.html?productId=${productId};
// }

// fetch specifica con id dei singoli prodotti 

let imgProdotto = document.querySelector('#imgProdotto');
let immagini = document.querySelector('#immagini');
let descrizioneProdotto = document.querySelector('#descrizioneProdotto');



const URLRICERCA = 'https://dummyjson.com/products/1'; //PATH VARIABLE
fetch(URLRICERCA)
    .then(response => {
        return response.json(); 
    })
    .then(prodotto =>{
        console.log(prodotto);
        stampaDettaglio(prodotto);
    })


function stampaDettaglio(prodotto){

    imgProdotto.setAttribute('src', prodotto.images[0]);

    prodotto.images.forEach(immagine => {
        immagini.innerHTML += `<div> <img class="img-fluid" src="${immagine}" alt="${prodotto.title}"> </div>`;    
    });

    descrizioneProdotto.innerHTML = `<p> ${prodotto.title} </p>
                                    <p> Categoria: ${prodotto.category} </p> 
                                    <p> Brand: ${prodotto.brand} </p> 
                                    <p> ${prodotto.description} </p> 
                                    <p> Prezzo: ${prodotto.price}€</p> 
                                    <p> Rating: ${prodotto.rating} </p> 
                                    <p> Stock: ${prodotto.stock} </p> 
`;
    
    
}

immagini.addEventListener('click', mostraImmagine); 


let i = 0; 

function mostraImmagine(prodotto){
    
    
}
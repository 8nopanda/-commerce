let btnCheckout = document.querySelector('#btnCheckout');
let listaProdotti = document.querySelector('#listaProdotti');
let checkboxDelete = document.querySelector('#checkboxDelete');


function povero(){
    alert("Non puoi acquistare, ti sei dimenticato di essere povero!");
}

btnCheckout.addEventListener('click', povero)

let carrello = localStorage.getItem('carrello');
let carrelloParse = JSON.parse(carrello);
console.log("carrello:",carrelloParse);

popolaCarrello();

function popolaCarrello(){
    carrelloParse.forEach(elemento => {
        listaProdotti.innerHTML += `<li class="listItem list-group-item list-group-item-action list-group-item-primary d-flex justify-content-between align-items-start">${elemento.title} - ${elemento.price}€ <i class="fa-solid fa-trash btnElimina"></i> </li>
        `;
    });
    console.log("ciao sono popolaCarrello:",carrelloParse);
    
    let btnElimina = document.querySelectorAll('.btnElimina');

    [...btnElimina].forEach(btnElimina => {
        btnElimina.addEventListener('click', eliminaProdotto);
    })
}
// taskContainer.addEventListener("animationend", function () {
//     taskContainer.remove();
//   });

//con flag elimina classe cambia in list-group-item-danger
// const checkboxFlag = true; 
// checkboxDelete.addEventListener('click',function() {
//     if(checkboxDelete.checked){
//         listItem.classList.remove("list-group-item-primary");
//         listItem.classList.add("list-group-item-danger");
//         checkboxFlag = true; 
//     }else{
//         listItem.classList.remove("list-group-item-danger");
//         listItem.classList.add("list-group-item-primary");
//         checkboxFlag = false;
//     }

// });

function seleziona(){
    if(checkboxDelete.checked == true){
        listItem.classList.remove("list-group-item-primary");
        listItem.classList.add("list-group-item-danger");
    }else{
        listItem.classList.remove("list-group-item-danger");
        listItem.classList.add("list-group-item-primary");
    }
}

function eliminaProdotto(){
    ul.removeChild(); 
}


//cancellare - stampare elenco aggiornato
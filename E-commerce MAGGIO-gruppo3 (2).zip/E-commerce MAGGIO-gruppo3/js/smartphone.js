let cardBody = document.querySelector('#cardBody');

let prodottiSmartphone = [];

function scegliProdottoSmartphone(){

    let prodottiScelti = 'https://dummyjson.com/products/category/smartphones'; 

        fetch(prodottiScelti)
            .then(response => {
                return response.json();
            })
            .then(prodotto =>{
               prodottiSmartphone.push(prodotto.products);
               stampaSmartphone(prodotto.products); 
               //console.log(prodotto);
            })
            
}
scegliProdottoSmartphone(); 
// console.log(prodottiSkincare);

function stampaSmartphone(prodottiSmartphone){
    prodottiSmartphone.forEach(prodottoSmartphone => {
        let card= `<div class="swiper-slide">
                                <div class="card">
                                    <div class="imgProdotto" style="background-image: url(${prodottoSmartphone.thumbnail})"></div>
                                    <div class="card-body d-flex flex-column">
                                    <h5 id="nomeSkincare" class="card-title">${prodottoSmartphone.title}</h5>
                                    <p id="brandSkincare" class="card-text">${prodottoSmartphone.brand}</p>
                                    <p id="descrizioneSkincare" class="card-text">${prodottoSmartphone.description}</p>
                                    <p id="prezzoSkincare" class="card-text">${prodottoSmartphone.price}€</p>
                                    <button id="btnAltreInfo" type="button" class="btn btn-primary mt-auto" data-bs-toggle="modal" data-bs-target="#prodotto1Modal"> Altre info </button>
                                    <button id="btnAggiungiCarrello" type="button" class="btn btn-primary mt-auto" onclick="aggiungiCarrello(${prodottoSmartphone.id})"> Aggiungi al carrello </button>
                                    </div>
                                </div>
    </div>`;
        cardBody.innerHTML += card;
    }); 
}

let arrayCarrello = []; //tabella

function aggiungiCarrello(prodottoId){
    const prodottiSceltiCarrello = `https://dummyjson.com/products/${prodottoId}`; 
    
    fetch(prodottiSceltiCarrello)
    .then(response => {
        return response.json();
    })
    .then(prodotto =>{
        let rigaCarrello = new RigaCarrello((arrayCarrello.length +1), prodotto, 1); //carrello_id contatore righe carrello +1 (auto_increment manuale)
        //oggetto rigaCarrello con dentro oggetto prodotto
        arrayCarrello.push(rigaCarrello);
        //console.log(arrayCarrello);
        //console.log("prodotto:" + prodotto);
        localStorage.setItem("arrayCarrello", JSON.stringify(arrayCarrello));
    })

}
//da sql a programmazione object
class RigaCarrello{
    constructor(carrello_id, prodotto, quantita){ //pk carrello_id univoco
        this.carrello_id = carrello_id; 
        this.prodotto = prodotto;
        this.quantita = quantita; 
    }
}

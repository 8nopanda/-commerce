let cardBody = document.querySelector('#cardBody');
let modalBody = document.querySelector('#modalBody');
let btnAltreInfo = document.querySelector('#btnAltreInfo');
let imgSkincare = document.querySelector('#imgSkincare');

let prodottiSkincare = [];


function scegliProdottoSkincare(){

    let prodottiScelti = 'https://dummyjson.com/products/category/skincare'; 

        fetch(prodottiScelti)
            .then(response => {
                return response.json();
            })
            .then(prodotto =>{
               prodottiSkincare.push(prodotto.products);
               stampaSkincare(prodotto.products); 
               //console.log(prodottiSkincare);
            })
            
}
scegliProdottoSkincare(); 
//console.log(prodottiSkincare);

function stampaSkincare(prodottiSkincare){
    prodottiSkincare.forEach(prodottoSkincare => {
        let card= `<div class="swiper-slide ${prodottoSkincare.id}">
                                <div class="card">
                                    <div class="imgProdotto" style="background-image: url(${prodottoSkincare.thumbnail})"></div>
                                    <div class="card-body d-flex flex-column">
                                    <h5 id="nomeSkincare" class="card-title">${prodottoSkincare.title}</h5>
                                    <p id="brandSkincare" class="card-text">${prodottoSkincare.brand}</p>
                                    <p id="descrizioneSkincare" class="card-text">${prodottoSkincare.description}</p>
                                    <p id="prezzoSkincare" class="card-text">${prodottoSkincare.price}€</p>
                                    <a href="info.html?id=${prodottoSkincare.id}" class="btn btn-primary" id="btnAltreInfo" >Altre info</a>
                                    <button type="button" class="btn btn-primary mt-auto" data-bs-toggle="modal" data-bs-target="#prodotto1Modal"> Aggiungi al carrello </button>
                                    </div>
                                </div>
    </div>`;
        cardBody.innerHTML += card;
    });
} 

//QUERY STRING 



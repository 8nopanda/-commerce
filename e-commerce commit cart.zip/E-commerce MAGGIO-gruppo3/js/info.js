// function apriPaginaInformazioni(productId) {
    // Reindirizza l'utente alla pagina "Informazioni" con l'ID del prodotto come parametro nella query string
//     window.location.href = informazioni.html?productId=${productId};
// }

// fetch specifica con id dei singoli prodotti 

let imgProdotto = document.querySelector('#imgProdotto');
let immagini = document.querySelector('#immagini');
let descrizioneProdotto = document.querySelector('#descrizioneProdotto');
let btnCarrello = document.querySelector('#btnCarrello');
let btnBack = document.querySelector('#btnBack');

const parametriURL = window.location.search; //finestra - url di base - parametri che seguono ?
console.log(parametriURL);

const parametriParsURL = new URLSearchParams(parametriURL); //coppie chiave-valori di cui fare un pars

let prodottoId = parametriParsURL.get('id');
console.log(prodottoId);
let arrayCarrello = [];

const URLRICERCA = `https://dummyjson.com/products/${prodottoId}`; //PATH VARIABLE

    fetch(URLRICERCA)
        .then(response => {
            return response.json(); 
        })
        .then(prodotto =>{
            console.log(prodotto);
            stampaDettaglio(prodotto);
            // prodotto.images.push(arrImmagini);
        })

    
    function stampaDettaglio(prodotto){
        
        imgProdotto.setAttribute('src', prodotto.images[0]);
        
        prodotto.images.forEach(immagine => {
            immagini.innerHTML += `<div> <img class="img-fluid imgMini" src="${immagine}" alt="${prodotto.title}"> </div>`;    
            let imgNodelist=document.querySelectorAll('.imgMini');
            [...imgNodelist].forEach(immagini=>{
                immagini.addEventListener('click', function(){
                imgProdotto.setAttribute('src',immagini.getAttribute('src'))
                //active con hover su css
            })
    
    })
    });
        
        descrizioneProdotto.innerHTML = ` <div id="info" class="h-100">
                                            <p> ${prodotto.title} </p>
                                            <p> Categoria: ${prodotto.category} </p> 
                                            <p> Brand: ${prodotto.brand} </p> 
                                            <p> ${prodotto.description} </p> 
                                            <p> Prezzo: ${prodotto.price}€</p> 
                                            <p> Rating: ${prodotto.rating} </p> 
                                            <p> Stock: ${prodotto.stock} </p> 
                                        </div>
        `;
        
    }
    


    function aggiungiCarrello(){
        
        fetch(URLRICERCA)
        .then(response => {
            return response.json(); 
        })
        .then(prodotto =>{
            arrayCarrello.push(prodotto);
            console.log(arrayCarrello);
            //console.log("prodotto:" + prodotto);
            localStorage.setItem("carrello", JSON.stringify(arrayCarrello));
            //console.log("nome prodotto:" + prodotto.title);
       
        })

    }

btnBack.addEventListener('click', goBack);

function goBack() {
    window.history.back();
}

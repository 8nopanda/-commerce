let cardBody = document.querySelector('#cardBody');
let modalBody = document.querySelector('#modalBody');
let btnAltreInfo = document.querySelector('#btnAltreInfo');
let imgSkincare = document.querySelector('#imgSkincare');

let nomeSkincare = document.querySelector('#nomeSkincare');
let modalProduct = document.querySelector('#modalProduct');
let btnAggiungiCarrello = document.querySelector('#btnAggiungiCarrello');

let prodottiSkincare = [];
console.log(prodottiSkincare);

function scegliProdottoSkincare(){

    const prodottiScelti = 'https://dummyjson.com/products/category/skincare'; 

        fetch(prodottiScelti)
            .then(response => {
                return response.json();
            })
            .then(prodotto =>{
               prodottiSkincare.push(prodotto.products);
               stampaSkincare(prodotto.products); 
               //console.log(prodottiSkincare);
            //    stampaModalSkincare(prodotto.products);
            })
            
}
scegliProdottoSkincare(); 
//console.log(prodottiSkincare);

function stampaSkincare(prodottiSkincare){
    prodottiSkincare.forEach(prodottoSkincare => {
        let card= `<div class="swiper-slide ${prodottoSkincare.id}">
                                <div class="card">
                                    <div class="imgProdotto" style="background-image: url(${prodottoSkincare.thumbnail})"></div>
                                    <div class="card-body d-flex flex-column">
                                    <h5 id="nomeSkincare" class="card-title">${prodottoSkincare.title}</h5>
                                    <p id="brandSkincare" class="card-text">${prodottoSkincare.brand}</p>
                                    <p id="descrizioneSkincare" class="card-text">${prodottoSkincare.description}</p>
                                    <p id="prezzoSkincare" class="card-text">${prodottoSkincare.price}€</p>
                                    <a href="info.html?id=${prodottoSkincare.id}" class="btn btn-primary" id="btnAltreInfo">Altre info</a>
                                    <button id="btnAggiungiCarrello" type="button" class="btn btn-primary mt-auto" onclick="aggiungiCarrello(${prodottoSkincare.id})"> Aggiungi al carrello </button>
                                    </div>
                                </div>
    </div>`;
        cardBody.innerHTML += card;
    });
} 

// data-bs-target="#prodotto1Modal" || data-bs-toggle="modal"

//QUERY STRING 
let arrayCarrello = [];

function aggiungiCarrello(prodottoId){
    const prodottiSceltiCarrello = `https://dummyjson.com/products/${prodottoId}`; 
    
    fetch(prodottiSceltiCarrello)
    .then(response => {
        return response.json();
    })
    .then(prodotto =>{
        arrayCarrello.push(prodotto);
        //console.log(arrayCarrello);
        //console.log("prodotto:" + prodotto);
        localStorage.setItem("carrello", JSON.stringify(arrayCarrello));
    })

}




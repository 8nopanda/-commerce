let btnCheckout = document.querySelector('#btnCheckout');
let listaProdotti = document.querySelector('#listaProdotti');
let checkboxDelete = document.querySelector('#checkboxDelete');


function povero(){
    alert("Non puoi acquistare, ti sei dimenticato di essere povero!");
}

btnCheckout.addEventListener('click', povero)

let carrello = localStorage.getItem('carrello');
let carrelloParse = JSON.parse(carrello); //arrayProdotti
//let carrello = JSON.parse(localStorage.getItem('carrello'))
console.log("carrello:",carrelloParse);

popolaCarrello();

function popolaCarrello(){
    carrelloParse.forEach(elemento => {
        listaProdotti.innerHTML += `<li class="listItem list-group-item list-group-item-action list-group-item-primary d-flex justify-content-between align-items-start" idProdotto="${elemento.id}"> ${elemento.title} - ${elemento.price}€ <i class="fa-solid fa-trash btnElimina"></i> </li>
        `;
    });
    console.log("ciao sono popolaCarrello:",carrelloParse);
    
    let btnElimina = document.querySelectorAll('.btnElimina');

    [...btnElimina].forEach(btnElimina => {
        btnElimina.addEventListener('click', eliminaProdotto);
    })
}

function eliminaProdotto(event){
    //console.log(event.target);
    
    let parent = this.parentNode;
    let idRimozione = parent.getAttribute("idProdotto");
    console.log(idRimozione);

    console.log(this);

    this.parentNode.remove();
    
    cercaProdottoLocalStorage(idRimozione);
}

function cercaProdottoLocalStorage(idRimozione){

    let elFiltrati = carrelloParse.filter((el) => idRimozione != el.id);

    console.log(elFiltrati);

    localStorage.setItem('carrello', JSON.stringify(elFiltrati)); //salvare in localStorage gli elementi filtrati
}



// let btnCheckout = document.querySelector('#btnCheckout');
// let listaProdotti = document.querySelector('#listaProdotti');
// let checkboxDelete = document.querySelector('#checkboxDelete');

// function povero(){
//     alert("Non puoi acquistare, ti sei dimenticato di essere povero!");
// }

// btnCheckout.addEventListener('click', povero);

// let carrello = localStorage.getItem('carrello');
// let carrelloParse = JSON.parse(carrello);
// console.log("carrello:",carrelloParse);

// popolaCarrello();

// function popolaCarrello(){
//     carrelloParse.forEach((elemento, index) => {
//         listaProdotti.innerHTML += `
//             <li prodotto_id=${index} class="listItem list-group-item list-group-item-action list-group-item-primary d-flex justify-content-between align-items-start">
//                 ${elemento.title} - ${elemento.price}€ 
//                 <i class="fa-solid fa-trash btnElimina" data-index="${index}"></i>
//             </li>
//         `;
//     });
//     console.log("ciao sono popolaCarrello:", carrelloParse);

//     let btnElimina = document.querySelectorAll('.btnElimina');
//     btnElimina.forEach(btn => {
//         btn.addEventListener('click', eliminaProdotto);
//     });
// }

// function eliminaProdotto(event){
//     let index = event.target.dataset.index;
//     carrelloParse.splice(index, 1); // Rimuovi l'elemento dal carrelloParse

//     // Aggiorna la localStorage con il carrello aggiornato
//     localStorage.setItem('carrello', JSON.stringify(carrelloParse));

//     // Rimuovi l'elemento dalla lista nella pagina HTML
//     event.target.parentElement.remove();

//     console.log(carrelloParse);
// };
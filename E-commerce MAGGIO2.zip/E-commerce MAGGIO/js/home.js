let inputRicerca = document.querySelector('#inputRicerca');
let outputRicerca = document.querySelector('#outputRicerca'); 

let btnRicerca = document.querySelector('#btnRicerca');

let imgSkincare = document.querySelector('#imgSkincare');
let nomeSkincare = document.querySelector('#nomeSkincare');
let brandSkincare = document.querySelector('#brandSkincare');
let descrizioneSkincare = document.querySelector('#descrizioneSkincare');
let prezzoSkincare = document.querySelector('#prezzoSkincare');






/* ---------------------------- RICERCA PRODOTTO ---------------------------- */
// function cercaProdotto() {
//     let nomeProdotto = inputRicerca.value; //salvo in una variabile la ricerca
//     nomeProdotto.replace(' ', '+'); //sostituisco spazi con + per permettere la ricerca

//     const URLRICERCA = `https://dummyjson.com/products/search?q=${nomeProdotto}`;

//     fetch(URLRICERCA)
//         .then(response => {
//             return response.json()
//         })
//         .then(mioProdotto => {
//             if(mioProdotto.title == undefined){
//                 outputRicerca.innerHTML = 'Prodotto non trovato';
//             }else{
//                 stampaProdottoCercato(mioProdotto.title, mioProdotto.description, mioProdotto.brand, mioProdotto.price);
//             }
//         console.log(mioProdotto);
//         })

//     function stampaProdottoCercato(nome, descrizione, brand, prezzo){
//         outputRicerca.innerHTML = ` <h1>${nome}</h1>
//                                     <ul>
//                                         <li>${brand}</li>
//                                         <li>${descrizione}</li>
//                                         <li>${prezzo}</li>
//                                     </ul>`;
//     }
    
// }

// btnRicerca.addEventListener('click', cercaProdotto);


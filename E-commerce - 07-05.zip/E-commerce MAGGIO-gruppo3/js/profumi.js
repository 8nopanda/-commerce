let cardBody = document.querySelector('#cardBody');
let btnAltreInfo = document.querySelector('#btnAltreInfo');

let prodottiProfumi = [];


function scegliProdottoProfumi(){

    let prodottiScelti = 'https://dummyjson.com/products/category/fragrances'; 

        fetch(prodottiScelti)
            .then(response => {
                return response.json();
            })
            .then(prodotto =>{
               prodottiProfumi.push(prodotto.products);
               stampaProdottiProfumi(prodotto.products);
               console.log(prodotto);
            })
            
}
scegliProdottoProfumi(); 
// console.log(prodottiSkincare);

function stampaProdottiProfumi(prodottiProfumi){
    prodottiProfumi.forEach(prodottoProfumi => {
        let card= `<div class="swiper-slide">
                                <div class="card">
                                    <div class="imgProdotto" style="background-image: url(${prodottoProfumi.thumbnail})"></div>
                                    <div class="card-body d-flex flex-column">
                                    <h5 id="nomeSkincare" class="card-title">${prodottoProfumi.title}</h5>
                                    <p id="brandSkincare" class="card-text">${prodottoProfumi.brand}</p>
                                    <p id="descrizioneSkincare" class="card-text">${prodottoProfumi.description}</p>
                                    <p id="prezzoSkincare" class="card-text">${prodottoProfumi.price}€</p>
                                    <button id="btnAltreInfo" type="button" class="btn btn-primary mt-auto" data-bs-toggle="modal" data-bs-target="#prodotto1Modal"> Altre info </button>
                                    </div>
                                </div>
    </div>`;
        cardBody.innerHTML += card;
    }); 
} 
